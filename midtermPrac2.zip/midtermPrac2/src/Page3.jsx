import React from 'react';
import { useState } from 'react';
import Header from './Header';
import Footer from './Footer';

import { useNavigate } from 'react-router-dom';
const Page3 = () => {
    const [text, SetText] = useState('')

 const navigate = useNavigate();

 const goToPage4 = () => {
   navigate('/Page4'); // Navigate to the Login page
 };
 function checkAnswer(){
    var answer = '4'
    if(text == answer){
      navigate('/Page4'); // Navigate to the Login page
    }
 }

   return (
     <div>
      <Header />
      <div>
        <a>
          <img src={"https://marvel-b1-cdn.bc0a.com/f00000000287107/www.murraystate.edu/news/images/Forbes_Best_Employer_3.jpg"} className="logo" alt="Vite logo" />
        </a>
      </div>
        <div>
       <p>This is Page3.</p>
       </div>
       <footer>
        <div>
            <p>What is 2+2?</p>
            <textarea onChange={(e)=> SetText(e.target.value)}></textarea>
            <button onClick={checkAnswer()}>CLICK</button>
        </div>
        <Footer />
     </footer>
     </div>
   );
 };
  export default Page3;