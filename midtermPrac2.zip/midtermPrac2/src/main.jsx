import React from 'react'
import Page1 from './Page1.jsx'
import Page2 from './Page2.jsx'
import Page3 from './Page3.jsx'
import Page4 from './Page4.jsx'
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import App from './App.jsx';
ReactDOM.createRoot(document.getElementById('root')).render(
 <React.StrictMode>
   <Router>
     <Routes>
       <Route path="/" element={<App/>} /> {/* page1 */}
       <Route path="/Page1" element={<Page1 />} /> {/* page1 */}
       <Route path="/Page2" element={<Page2 />} /> {/* page2 */}
       <Route path="/Page3" element={<Page3 />} /> {/* page3 */}
       <Route path="/Page4" element={<Page4 />} /> {/* page4 */}
     </Routes>
   </Router>
 </React.StrictMode>
);
