import React from 'react';
import Header from './Header';
import Footer from './Footer';

import { useNavigate } from 'react-router-dom';
const Page1 = () => {

 const navigate = useNavigate();

 const goToPage2 = () => {
   navigate('/Page2'); // Navigate to the page2
 };

   return (
     <div>
      <Header />
        <div>
        <a>
          <img src={"https://marvel-b1-cdn.bc0a.com/f00000000287107/www.murraystate.edu/_images/2col/students-clock-tower-2022-01.jpg"} className="logo" alt="Vite logo" />
        </a>
      </div>
       <p>This is Page1.</p>
       <button onClick={goToPage2}>Go to page2</button>
     
       <footer>
        <div>
            <p>Page 1 is for posers</p>
        </div>
        <Footer />
     </footer>
     </div>
     
   );
 };
  export default Page1;
