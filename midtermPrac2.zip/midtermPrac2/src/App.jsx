import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';

function App() {
const Home = () => {

 const navigate = useNavigate();

 const goToPage1 = () => {
   navigate('/Page1'); // Navigate to the page2
 };

   return (
    <>
     <div>
       <Header />
       <p>This is Home.</p>
       <Link to={"/"}>Go to Home</Link>
     </div>
     <div>
       <Link to={"/Page1"}>Go to Page1</Link>
     </div>
     <div>
       <Link to={"/Page2"}>Go to Page2</Link>
     </div>
     <div>
       <Link to={"/Page3"}>Go to Page3</Link>
     </div>
     <div>
       <Link to={"/Page4"}>Go to Page4</Link>
     </div>
     </>
   );
   
 };

  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <Home></Home>
      </div>
      <h1>MidTermPrac2</h1>
      <div className="card">
      <a>
          <img src={"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRba0U4tXXV4TJRPBrlQImdo1dhmLpo737QqA&s"} className="logo" alt="Vite logo" />
      </a>
      </div>
      <footer>
        Picture of Murray State University
        <Footer />
      </footer>
    </>
  )
}

export default App
