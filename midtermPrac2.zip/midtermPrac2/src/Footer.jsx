import React from 'react';
import './App.css';
const Footer = () => {
    return (
      <footer className="mp2-footer">
        <h1>Welcome to the footer</h1>
      </footer>
    );
  };
  
  export default Footer;