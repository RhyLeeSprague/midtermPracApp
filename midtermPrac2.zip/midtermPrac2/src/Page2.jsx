import React from 'react';
import Header from './Header';
import Footer from './Footer';

import { useNavigate } from 'react-router-dom';
const Page2 = () => {

 const navigate = useNavigate();

 const goToPage3 = () => {
   navigate('/Page3'); // Navigate to the page3
 };

   return (
     <div>
      <Header />
     <div>
     <div>
        <a>
          <img src={"https://marvel-b1-cdn.bc0a.com/f00000000287107/www.murraystate.edu/news/images/Twilight_Tours.jpg"} className="logo" alt="Vite logo" />
        </a>
      </div>
       <p>This is Page2.</p>
       <button onClick={goToPage3}>Go to page3</button>
     </div>
     <footer>
     <div>
         <p>Page 2 is for cool kids</p>
     </div>
     <Footer />
  </footer>
    </div>
   );
 };

 
  export default Page2;