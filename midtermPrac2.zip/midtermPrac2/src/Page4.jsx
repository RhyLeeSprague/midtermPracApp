import React from 'react';
import Header from './Header';
import Footer from './Footer';

import { useNavigate } from 'react-router-dom';
const Page4 = () => {

 const navigate = useNavigate();

 const goHome = () => {
   navigate('/'); // Navigate to the Login page
 };

   return (
     <div>
      <Header />
      <div>
        <a>
          <img src={"https://images.sidearmdev.com/resize?url=https%3A%2F%2Fdxbhsrqyrr690.cloudfront.net%2Fsidearm.nextgen.sites%2Fmurraystate.sidearmsports.com%2Fimages%2F2023%2F2%2F1%2FStewart_Drone.jpeg&height=300&type=webp"} className="logo" alt="Vite logo" />
        </a>
      </div>
       <p>This is Page4.</p>
       <button onClick={goHome}>Go to Home</button>
       <Footer />
     </div>
   );
 };
  export default Page4;