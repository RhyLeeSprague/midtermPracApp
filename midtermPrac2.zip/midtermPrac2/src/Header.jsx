import React from 'react';
import './App.css';
const Header = () => {
    return (
      <header className="as5-header">
        <h1>Welcome to the header</h1>
      </header>
    );
  };
  
  export default Header;